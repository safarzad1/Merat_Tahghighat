import { NextRequest, NextResponse } from "next/server";
import sql from "mssql";

import { getConnection } from "@/Lib/db";
import { verifyToken } from "@/Lib/auth";

export async function POST(req: NextRequest) {
    const token = req.cookies.get("token")?.value;
    if (!token) {
        return NextResponse.json(
            { status: 401, error: "Unauthorized: No token" },
            { status: 401 }
        );
    }

    const body = await req.json();
    const { erjaid, isdone, erjaLastState, sharheghdam, userid } = body;

    if (!erjaid) {
        return NextResponse.json({ error: "page required" }, { status: 400 });
    }

    try {
        verifyToken(token);
    } catch {
        return NextResponse.json(
            { status: 401, error: "Unauthorized: Invalid or expired token" },
            { status: 401 }
        );
    }

    try {
        const pool = await getConnection();
        const result = await pool
            .request()
            .input("ErjaId", sql.BigInt, erjaid)
            .input("ErjaLastState", sql.Int, erjaLastState)
            .input("SharhEghdam", sql.NVarChar(3000), sharheghdam)
            .input("UserId", sql.BigInt, userid)
            .execute("Tahghighat.SP_Update_ErjaState");

        return NextResponse.json(
            { status: 200, data: result.recordset }
        );

    } catch (err) {
        return NextResponse.json(
            { error: err instanceof Error ? err.message : "Unknown error" },
            { status: 500 }
        );
    }
}
