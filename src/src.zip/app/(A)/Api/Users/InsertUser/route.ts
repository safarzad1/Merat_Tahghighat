import { NextRequest, NextResponse } from "next/server";
import sql from "mssql";

import { getConnection } from "@/Lib/db";
import { verifyToken } from "@/Lib/auth";

export async function POST(req: NextRequest) {
    const token = req.cookies.get("token")?.value;
    if (!token) {
        return NextResponse.json(
            { status: 401, error: "Unauthorized: No token" },
            { status: 401 }
        );
    }

    const body = await req.json();
    const { userId, mahal, personId, postId, password, createUserId } = body;

    if (!mahal) {
        return NextResponse.json({ error: "mahal required" }, { status: 400 });
    }

    try {
        verifyToken(token);
    } catch {
        return NextResponse.json(
            { status: 401, error: "Unauthorized: Invalid or expired token" },
            { status: 401 }
        );
    }

    try {
        const pool = await getConnection();
        const result = await pool
            .request()
            .input("UserId", sql.BigInt, userId)
            .input("PersonId", sql.BigInt, personId)
            .input("PostId", sql.Int, postId)
            .input("Mahal", sql.Int, mahal)
            .input("Password", sql.NVarChar(200), password)
            .input("CreateUserId", sql.BigInt, createUserId)
            .execute("Users.SP_InsertUser");

        return NextResponse.json(
            { status: 200, data: result.recordset }
        );

    } catch (err) {
        return NextResponse.json(
            { error: err instanceof Error ? err.message : "Unknown error" },
            { status: 500 }
        );
    }
}
